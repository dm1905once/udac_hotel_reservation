package model;

public class Tester {
    public static void main(String[] args) {
        Customer customer = new Customer("Bob", "Patino", "bob@patino.com");
        System.out.println(customer);
    }
}
